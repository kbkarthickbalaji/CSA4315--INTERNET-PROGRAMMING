# Internet Programming Lab — Experiments 1 to 7

This ZIP contains seven separate responsive front-end demonstrations in the exact order from the supplied question sheet.

## Experiments
1. Library Management System
2. Hotel Room Booking
3. Bus Ticket Booking
4. Train Reservation System
5. Flight Reservation System
6. Online Cake Ordering System
7. Beauty Parlour Appointment Booking System

## How to run
1. Extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open any experiment folder (for example, `01_Library_Management`).
4. Open `index.html` in a browser. You can also use the VS Code Live Server extension.
5. Try the forms, searches and dashboard. Demo records are stored in the browser's localStorage.

## Files in each experiment
- `index.html` — webpage and forms
- `style.css` — responsive styling
- `script.js` — front-end interactions and local demo storage

## Important limitation
These are HTML/CSS/JavaScript front-end lab demos. They do not connect to a real database or implement production authentication, live inventory, actual payment processing, email/SMS delivery, or real transport/salon booking services. Payment, booking and admin interactions are simulated locally. Never enter real passwords, card numbers or sensitive personal information.
