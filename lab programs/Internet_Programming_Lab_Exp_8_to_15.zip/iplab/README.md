# Internet Programming Lab – Experiments 8 to 15

Pure HTML + CSS + JavaScript (no installation, no server). Open `index.html` in a browser, or open any
`NN_name/index.html` directly. Keep the folder structure (each page uses `../common.js` and `../style.css`).

Data is stored in the browser's localStorage (acts as the database). Passwords are stored in plain text
because this is a lab demo only. Google Maps (Exp 8, 11) and QR images (Exp 15) need an internet connection.

Default admin login for every experiment: `admin` / `admin123`. Other users register themselves.

| # | Experiment | Roles | Main features |
|---|-----------|-------|---------------|
| 8 | MedCare Hospital | Patient, Admin | Search doctor by specialty/location, book slot, check-in form, cancel, history, reviews/ratings, Google map; admin manages doctors, appointments, statistics |
| 9 | TechSavvy | Customer, Admin | Categories/sub-categories, search & filter, cart (add/edit/remove), checkout, order status, history, wish list; admin add/remove items, change price/description, view customers |
| 10 | StyleHub | Customer, Admin | Same engine as 9 with fashion catalogue |
| 11 | Home Finder | Buyer, Admin | Login, property search, save/reuse search criteria, Google Maps, favourites, schedule viewing, agent/company search, mortgage calculator; admin properties, agents, visitor records |
| 12 | InsureEasy | Admin, Agent, Policy holder | Agent registers and admin approves; agent creates customers, manages policies, sends SMS alerts (simulated); customer views policies, pays premium, reads alerts |
| 13 | BlossomGifts | Customer, Admin | Same engine as 9 with occasions, delivery date/time and gift message |
| 14 | ReNewMarket | User, Admin | List items, browse/filter, buy, make offers; admin manages users, categories, commodities, orders (Shipped/Received, delete) |
| 15 | EasyToll | Driver, Toll gate staff, Admin | eWallet, eTicket, apply/renew pass, QR codes; admin approves passes, creates toll gates and gate logins; gate staff scan/verify and update location |

SMS and payments are simulated (no real gateway). To reset a project's data, clear the site data/localStorage in the browser.
